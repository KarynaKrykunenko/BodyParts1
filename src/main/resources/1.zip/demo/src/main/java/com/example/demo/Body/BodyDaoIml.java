package com.example.demo.Body;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BodyDaoIml implements IBodyDao {


   private DataSource dataSource1;
   private DataSource dataSource2;
   private DataSource dataSource3;
   private DataSource dataSource4;
   private DataSource dataSource5;
   private DataSource dataSource6;
   private DataSource dataSource7;
   private DataSource dataSource8;
   private DataSource dataSource9;
   private DataSource dataSource10;
   private DataSource dataSource11;
   private DataSource dataSource12;
   private DataSource dataSource13;
   private DataSource dataSource14;
   private DataSource dataSource15;
   private DataSource dataSource16;
   private DataSource dataSource17;

    public DataSource getDataSource1() {
        return dataSource1;
    }

    public void setDataSource1(DataSource dataSource1) {
        this.dataSource1 = dataSource1;
    }

    public DataSource getDataSource2() {
        return dataSource2;
    }

    public void setDataSource2(DataSource dataSource2) {
        this.dataSource2 = dataSource2;
    }

    public DataSource getDataSource3() {
        return dataSource3;
    }

    public void setDataSource3(DataSource dataSource3) {
        this.dataSource3 = dataSource3;
    }

    public DataSource getDataSource4() {
        return dataSource4;
    }

    public void setDataSource4(DataSource dataSource4) {
        this.dataSource4 = dataSource4;
    }

    public DataSource getDataSource5() {
        return dataSource5;
    }

    public void setDataSource5(DataSource dataSource5) {
        this.dataSource5 = dataSource5;
    }

    public DataSource getDataSource6() {
        return dataSource6;
    }

    public void setDataSource6(DataSource dataSource6) {
        this.dataSource6 = dataSource6;
    }

    public DataSource getDataSource7() {
        return dataSource7;
    }

    public void setDataSource7(DataSource dataSource7) {
        this.dataSource7 = dataSource7;
    }

    public DataSource getDataSource8() {
        return dataSource8;
    }

    public void setDataSource8(DataSource dataSource8) {
        this.dataSource8 = dataSource8;
    }

    public DataSource getDataSource9() {
        return dataSource9;
    }

    public void setDataSource9(DataSource dataSource9) {
        this.dataSource9 = dataSource9;
    }

    public DataSource getDataSource10() {
        return dataSource10;
    }

    public void setDataSource10(DataSource dataSource10) {
        this.dataSource10 = dataSource10;
    }

    public DataSource getDataSource11() {
        return dataSource11;
    }

    public void setDataSource11(DataSource dataSource11) {
        this.dataSource11 = dataSource11;
    }

    public DataSource getDataSource12() {
        return dataSource12;
    }

    public void setDataSource12(DataSource dataSource12) {
        this.dataSource12 = dataSource12;
    }

    public DataSource getDataSource13() {
        return dataSource13;
    }

    public void setDataSource13(DataSource dataSource13) {
        this.dataSource13 = dataSource13;
    }

    public DataSource getDataSource14() {
        return dataSource14;
    }

    public void setDataSource14(DataSource dataSource14) {
        this.dataSource14 = dataSource14;
    }

    public DataSource getDataSource15() {
        return dataSource15;
    }

    public void setDataSource15(DataSource dataSource15) {
        this.dataSource15 = dataSource15;
    }

    public DataSource getDataSource16() {
        return dataSource16;
    }

    public void setDataSource16(DataSource dataSource16) {
        this.dataSource16 = dataSource16;
    }

    public DataSource getDataSource17() {
        return dataSource17;
    }

    public void setDataSource17(DataSource dataSource17) {
        this.dataSource17 = dataSource17;
    }

    public DataSource getDataSource18() {
        return dataSource18;
    }

    public void setDataSource18(DataSource dataSource18) {
        this.dataSource18 = dataSource18;
    }

    private DataSource dataSource18;



    private int id;
    private int id2;
    private int id3;
    private int id4;
    private int id5;
    private int id6;
    private int id7;
    private int id8;

    public int getId7() {
        return id7;
    }

    public void setId7(int id7) {
        this.id7 = id7;
    }

    public int getId8() {
        return id8;
    }

    public void setId8(int id8) {
        this.id8 = id8;
    }

    public int getId9() {
        return id9;
    }

    public void setId9(int id9) {
        this.id9 = id9;
    }

    public int getId10() {
        return id10;
    }

    public void setId10(int id10) {
        this.id10 = id10;
    }


    public int getId11() {
        return id11;
    }

    public void setId11(int id11) {
        this.id11 = id11;
    }

    public int getId12() {
        return id12;
    }

    public void setId12(int id12) {
        this.id12 = id12;
    }

    public int getId13() {
        return id13;
    }

    public void setId13(int id13) {
        this.id13 = id13;
    }

    public int getId14() {
        return id14;
    }

    public void setId14(int id14) {
        this.id14 = id14;
    }

    public int getId15() {
        return id15;
    }

    public void setId15(int id15) {
        this.id15 = id15;
    }

    public int getId16() {
        return id16;
    }

    public void setId16(int id16) {
        this.id16 = id16;
    }

    public int getId17() {
        return id17;
    }

    public void setId17(int id17) {
        this.id17 = id17;
    }

    public int getId18() {
        return id18;
    }

    public void setId18(int id18) {
        this.id18 = id18;
    }

    private int id9;
    private int id10;
    private int id11;
    private int id12;
    private int id13;
    private int id14;
    private int id15;
    private int id16;
    private int id17;
    private int id18;

    public int getId5() {
        return id5;
    }

    public void setId5(int id5) {
        this.id5 = id5;
    }

    public int getId6() {
        return id6;
    }

    public void setId6(int id6) {
        this.id6 = id6;
    }

    private String url1;

    public String getUrl1() {
        return url1;
    }

    public void setUrl1(String url1) {
        this.url1 = url1;
    }

    private String url2;
    private String url3;
    private String url4;
    private String url5;
    private String url6;
    private String url7;
    private String url8;
    private String url9;
    private String url10;
    private String url11;
    private String url12;
    private String url13;
    private String url14;
    private String url15;
    private String url16;
    private String url17;
    private String url18;

    public String getUrl5() {
        return url5;
    }

    public void setUrl5(String url5) {
        this.url5 = url5;
    }

    public String getUrl6() {
        return url6;
    }

    public void setUrl6(String url6) {
        this.url6 = url6;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId2() {
        return id2;
    }

    public void setId2(int id2) {
        this.id2 = id2;
    }

    public int getId3() {
        return id3;
    }

    public void setId3(int id3) {
        this.id3 = id3;
    }

    public int getId4() {
        return id4;
    }

    public void setId4(int id4) {
        this.id4 = id4;
    }

    public String getUrl2() {
        return url2;
    }

    public void setUrl2(String url2) {
        this.url2 = url2;
    }

    public String getUrl3() {
        return url3;
    }

    public void setUrl3(String url3) {
        this.url3 = url3;
    }

    public String getUrl4() {
        return url4;
    }

    public void setUrl4(String url4) {
        this.url4 = url4;
    }


    @Override
    public String initBodyDao1(BodyDaoIml bodyDao1) throws SQLException {
        Connection connection = null;
        String sqlSelect1 = "select urlgif from BodyParts where id=" + getId();
        try {
            connection = dataSource1.getConnection();
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(sqlSelect1);
            while (resultSet1.next()) {

                bodyDao1.setUrl1(resultSet1.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao1.getUrl1();
    }

    @Override
    public String initBodyDao2(BodyDaoIml bodyDao2) throws SQLException {
        Connection connection = null;
        String sqlSelect2 = "select urlgif from BodyParts where id=" + getId2();
        try {
            connection = dataSource2.getConnection();
            Statement statement2 = connection.createStatement();
            ResultSet resultSet2 = statement2.executeQuery(sqlSelect2);
            while (resultSet2.next()) {

                bodyDao2.setUrl1(resultSet2.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao2.getUrl2();
    }

    @Override
    public String initBodyDao3(BodyDaoIml bodyDao3) throws SQLException {
        Connection connection = null;
        String sqlSelect3 = "select urlgif from BodyParts where id=" + getId3();
        try {
            connection = dataSource3.getConnection();
            Statement statement3 = connection.createStatement();
            ResultSet resultSet3 = statement3.executeQuery(sqlSelect3);
            while (resultSet3.next()) {

                bodyDao3.setUrl3(resultSet3.getString(1));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao3.getUrl3();
    }

    @Override
    public String initBodyDao4(BodyDaoIml bodyDao4) throws SQLException {
        Connection connection = null;
        String sqlSelect4 = "select urlgif from BodyParts where id=" + getId4();
        try {
            connection = dataSource4.getConnection();
            Statement statement4 = connection.createStatement();
            ResultSet resultSet4 = statement4.executeQuery(sqlSelect4);
            while (resultSet4.next()) {

                bodyDao4.setUrl4(resultSet4.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao4.getUrl4();
    }

    @Override
    public String initBodyDao5(BodyDaoIml bodyDao5) throws SQLException {
        Connection connection5 = null;
        String sqlSelect5 = "select urlgif from BodyParts where id=" + getId5();
        try {
            connection5 = dataSource5.getConnection();
            Statement statement5 = connection5.createStatement();
            ResultSet resultSet5 = statement5.executeQuery(sqlSelect5);
            while (resultSet5.next()) {
                bodyDao5.setUrl5(resultSet5.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao5.getUrl5();
    }

    @Override
    public String initBodyDao6(BodyDaoIml bodyDao6) throws SQLException {
        Connection connection6 = null;
        String sqlSelect6 = "select urlgif from BodyParts where id=" + getId6();
        try {
            connection6 = dataSource6.getConnection();
            Statement statement6 = connection6.createStatement();
            ResultSet resultSet6 = statement6.executeQuery(sqlSelect6);
            while (resultSet6.next()) {
                bodyDao6.setUrl6(resultSet6.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao6.getUrl6();
    }

    public String getUrl7() {
        return url7;
    }

    public void setUrl7(String url7) {
        this.url7 = url7;
    }

    public String getUrl8() {
        return url8;
    }


    public void setUrl8(String url8) {
        this.url8 = url8;
    }

    public String getUrl9() {
        return url9;
    }

    public void setUrl9(String url9) {
        this.url9 = url9;
    }

    public String getUrl10() {
        return url10;
    }

    public void setUrl10(String url10) {
        this.url10 = url10;
    }

    public String getUrl11() {
        return url11;
    }

    public void setUrl11(String url11) {
        this.url11 = url11;
    }

    public String getUrl12() {
        return url12;
    }

    public void setUrl12(String url12) {
        this.url12 = url12;
    }

    public String getUrl13() {
        return url13;
    }

    public void setUrl13(String url13) {
        this.url13 = url13;
    }

    public String getUrl14() {
        return url14;
    }

    public void setUrl14(String url14) {
        this.url14 = url14;
    }

    public String getUrl15() {
        return url15;
    }

    public void setUrl15(String url15) {
        this.url15 = url15;
    }

    public String getUrl16() {
        return url16;
    }

    public void setUrl16(String url16) {
        this.url16 = url16;
    }

    public String getUrl17() {
        return url17;
    }

    public void setUrl17(String url17) {
        this.url17 = url17;
    }

    public String getUrl18() {
        return url18;
    }

    public void setUrl18(String url18) {
        this.url18 = url18;
    }

    @Override
    public String initBodyDao7(BodyDaoIml bodyDao7) throws SQLException {
        Connection connection7 = null;
        String sqlSelect7 = "select urlgif from BodyParts where id=" + getId7();
        try {
            connection7 = dataSource7.getConnection();
            Statement statement7 = connection7.createStatement();
            ResultSet resultSet7 = statement7.executeQuery(sqlSelect7);
            while (resultSet7.next()) {
                bodyDao7.setUrl7(resultSet7.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao7.getUrl7();
    }

    @Override
    public String initBodyDao8(BodyDaoIml bodyDao8) throws SQLException {
        Connection connection8 = null;
        String sqlSelect8 = "select urlgif from BodyParts where id=" + getId8();
        try {
            connection8 = dataSource8.getConnection();
            Statement statement8 = connection8.createStatement();
            ResultSet resultSet8 = statement8.executeQuery(sqlSelect8);
            while (resultSet8.next()) {
                bodyDao8.setUrl8(resultSet8.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao8.getUrl8();
    }

    @Override
    public String initBodyDao9(BodyDaoIml bodyDao9) throws SQLException {
        Connection connection9 = null;
        String sqlSelect9 = "select urlgif from BodyParts where id=" + getId9();
        try {
            connection9 = dataSource9.getConnection();
            Statement statement9 = connection9.createStatement();
            ResultSet resultSet9 = statement9.executeQuery(sqlSelect9);
            while (resultSet9.next()) {
                bodyDao9.setUrl9(resultSet9.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao9.getUrl9();
    }

    @Override
    public String initBodyDao10(BodyDaoIml bodyDao10) throws SQLException {
        Connection connection10 = null;
        String sqlSelect10 = "select urlgif from BodyParts where id=" + getId10();
        try {
            connection10 = dataSource10.getConnection();
            Statement statement10 = connection10.createStatement();
            ResultSet resultSet10 = statement10.executeQuery(sqlSelect10);
            while (resultSet10.next()) {
                bodyDao10.setUrl10(resultSet10.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao10.getUrl10();
    }


    @Override
    public String initBodyDao11(BodyDaoIml bodyDao11) throws SQLException {
        Connection connection11 = null;
        String sqlSelect11 = "select urlgif from BodyParts where id=" + getId11();
        try {
            connection11 = dataSource11.getConnection();
            Statement statement11 = connection11.createStatement();
            ResultSet resultSet11 = statement11.executeQuery(sqlSelect11);
            while (resultSet11.next()) {
                bodyDao11.setUrl11(resultSet11.getString(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bodyDao11.getUrl11();
    }

    @Override
    public String initBodyDao12(BodyDaoIml bodyDao12) throws SQLException {
        Connection connection12 = null;
        String sqlSelect12 = "select urlgif from BodyParts where id=" + getId12();
        try {
            connection12 = dataSource12.getConnection();
            Statement statement12 = connection12.createStatement();
            ResultSet resultSet12 = statement12.executeQuery(sqlSelect12);
            while (resultSet12.next())

            bodyDao12.setUrl12(resultSet12.getString(1));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bodyDao12.getUrl12();
    }

    @Override
    public String initBodyDao13(BodyDaoIml bodyDao13) throws SQLException {
        Connection connection13=null;
        String sqlSelect13="select urlgif from BodyParts where id=" + getId13();
        try {
            connection13=dataSource13.getConnection();
            Statement statement13=connection13.createStatement();
            ResultSet resultSet13=statement13.executeQuery(sqlSelect13);
            while (resultSet13.next()){
                bodyDao13.setUrl13(resultSet13.getString(1));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return bodyDao13.getUrl13();
    }

    @Override
    public String initBodyDao14(BodyDaoIml bodyDao14) throws SQLException {
        Connection connection14=null;
        String sqlSelect14="select urlgif from BodyParts where id=" + getId14();
        try {
            connection14=dataSource14.getConnection();
            Statement statement14=connection14.createStatement();
            ResultSet resultSet14=statement14.executeQuery(sqlSelect14);
            while (resultSet14.next()){
                bodyDao14.setUrl14(resultSet14.getString(1));
            }
        }catch (SQLException e){
            e.printStackTrace();
         }return bodyDao14.getUrl14();
    }

    @Override
    public String initBodyDao15(BodyDaoIml bodyDao15) throws SQLException {
        Connection connection15=null;
        String sqlSelect15="select urlgif from BodyParts where id=" + getId15();
        try {
            connection15=dataSource15.getConnection();
            Statement statement15=connection15.createStatement();
            ResultSet resultSet15=statement15.executeQuery(sqlSelect15);
            while (resultSet15.next()){
                bodyDao15.setUrl15(resultSet15.getString(1));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return bodyDao15.getUrl15();
    }

    @Override
    public String initBodyDao16(BodyDaoIml bodyDao16) throws SQLException {
        Connection connection16=null;
        String sqlSelect16="select urlgif from BodyParts where id=" + getId16();
        try {
            connection16=dataSource16.getConnection();
            Statement statement16=connection16.createStatement();
            ResultSet resultSet16=statement16.executeQuery(sqlSelect16);
            while (resultSet16.next()){
                bodyDao16.setUrl16(resultSet16.getString(1));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return bodyDao16.getUrl16();
    }

    @Override
    public String initBodyDao17(BodyDaoIml bodyDao17) throws SQLException {
        Connection connection17=null;
        String sqlSelect17="select urlgif from BodyParts where id=" + getId17();
        try {
            connection17=dataSource17.getConnection();
            Statement statement17=connection17.createStatement();
            ResultSet resultSet17=statement17.executeQuery(sqlSelect17);
            while (resultSet17.next()){
                bodyDao17.setUrl17(resultSet17.getString(1));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return bodyDao17.getUrl17();
    }

    @Override
    public String initBodyDao18(BodyDaoIml bodyDao18) throws SQLException {
        Connection connection18=null;
        String sqlSelect18="select urlgif from BodyParts where id=" + getId18();
        try {
            connection18=dataSource18.getConnection();
            Statement statement18=connection18.createStatement();
            ResultSet resultSet18=statement18.executeQuery(sqlSelect18);
            while (resultSet18.next()){
                bodyDao18.setUrl17(resultSet18.getString(1));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return bodyDao18.getUrl18();
    }
}