package com.example.demo.Body;

import java.sql.SQLException;

public interface IBodyDao {


    String initBodyDao1(BodyDaoIml bodyDao) throws SQLException;



    String initBodyDao2(BodyDaoIml bodyDao2) throws SQLException;



    String initBodyDao3(BodyDaoIml bodyDao3) throws SQLException;



    String initBodyDao4(BodyDaoIml bodyDao4) throws SQLException;

    String initBodyDao5(BodyDaoIml bodyDao5) throws SQLException;

    String initBodyDao6(BodyDaoIml bodyDao6) throws SQLException;

    String initBodyDao7(BodyDaoIml bodyDao7) throws SQLException;

    String initBodyDao8(BodyDaoIml bodyDao8) throws SQLException;

    String initBodyDao9(BodyDaoIml bodyDao9) throws SQLException;

    String initBodyDao10(BodyDaoIml bodyDao10) throws SQLException;

    String initBodyDao11(BodyDaoIml bodyDao11) throws SQLException;

    String initBodyDao12(BodyDaoIml bodyDao12) throws SQLException;

    String initBodyDao13(BodyDaoIml bodyDao13) throws SQLException;

    String initBodyDao14(BodyDaoIml bodyDao14) throws SQLException;

    String initBodyDao15(BodyDaoIml bodyDao15) throws SQLException;

    String initBodyDao16(BodyDaoIml bodyDao16) throws SQLException;

    String initBodyDao17(BodyDaoIml bodyDao17) throws SQLException;

    String initBodyDao18(BodyDaoIml bodyDao18) throws SQLException;


}
