package com.example.demo.image;

import java.sql.SQLException;

public interface IImageDao {

   public String initImageDao1(ImageDaoImpl imageDao1) throws SQLException;
   public String initImageDao2(ImageDaoImpl imageDao1) throws SQLException;
   public String initImageDao3(ImageDaoImpl imageDao1) throws SQLException;
   public String initImageDao4(ImageDaoImpl imageDao1) throws SQLException;
}
